import{ Component} from '@angular/core';

@Component({
    selector:'classStyle-binding',
    templateUrl:'./ClassStyleBindingComponent.html'
})
    
export class  ClassStyleBindingComponent{
    public title:string= "Class Binding and Style Binding";
    
}
