import {Component} from '@angular/core';

@Component({
	selector:'home-page',
	templateUrl: './HomePageComponent.html'
})

export class HomePageComponent{
	public title:string = "Home Page";
}