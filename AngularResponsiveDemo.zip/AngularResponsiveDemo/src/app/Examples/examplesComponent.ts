import{ Component} from '@angular/core';

@Component({
    selector:'example',
    templateUrl:'./examplesComponent.html'
})

export class  examplesComponent{
    public title:string= "Different Examples"
}