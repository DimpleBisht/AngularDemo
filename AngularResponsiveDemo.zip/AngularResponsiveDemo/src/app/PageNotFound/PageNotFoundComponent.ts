import{ Component} from '@angular/core';

@Component({
    selector:'error-page',
    templateUrl:'./PageNotFoundComponent.html'
})
    
export class  PageNotFoundComponent{
    public title:string= "Page Not Found !!";
}
