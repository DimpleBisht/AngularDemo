import {Component} from '@angular/core';

@Component({
	selector:'event-binding',
	templateUrl: './EventBindingComponent.html'
})

export class EventBindingComponent{
	public title:string = "Event Binding Page";
}